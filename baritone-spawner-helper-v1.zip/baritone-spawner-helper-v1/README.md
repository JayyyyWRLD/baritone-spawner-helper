# Baritone Spawner Helper v1

Baritone Spawner Helper v1 is a small client-side Fabric utility for Minecraft 1.21.4.

When enabled, it starts Baritone with `#mine minecraft:spawner`, watches for dropped spawner item entities nearby, cancels the current path, and routes Baritone to the dropped item position with `#goto x y z`.

## Controls

- Toggle: `F7` by default
- Settings screen: `/baritonespawnerhelper` or `/baritonespawnerhelper config`
- Keybinds: `Options > Controls > Baritone Spawner Helper v1`

## Behavior

1. Start `#mine minecraft:spawner` when enabled.
2. Detect nearby dropped spawner `ItemEntity` objects.
3. Cancel the active Baritone task.
4. Run `#goto x y z` using the dropped spawner coordinates.
5. Resume mining after pickup, item removal, or timeout.

## Build

Windows:

```bat
.\gradlew.bat clean build
```

Linux/macOS:

```sh
chmod +x gradlew
./gradlew clean build
```

Output:

```text
build/libs/baritone-spawner-helper-v1-1.0.0.jar
```

## Requirements

- Minecraft 1.21.4
- Fabric Loader 0.16.9+
- Fabric API
- Java 21
- Baritone for Fabric 1.21.4

## Notes

Baritone Spawner Helper v1 does not bundle Baritone. Install Baritone separately.
