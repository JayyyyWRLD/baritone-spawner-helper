@echo off
setlocal enabledelayedexpansion

set GRADLE_VERSION=8.11.1
set BASE_DIR=%~dp0
set LOCAL_DIR=%BASE_DIR%.gradle-local
set DIST_DIR=%LOCAL_DIR%\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%DIST_DIR%\bin\gradle.bat
set GRADLE_ZIP=%LOCAL_DIR%\gradle-%GRADLE_VERSION%-bin.zip
set DOWNLOAD_SCRIPT=%BASE_DIR%gradle\download-gradle.ps1

if not exist "%GRADLE_BIN%" (
    echo Gradle %GRADLE_VERSION% not found locally.
    echo Downloading Gradle %GRADLE_VERSION%. First build needs internet access.

    if not exist "%LOCAL_DIR%" mkdir "%LOCAL_DIR%"

    powershell -NoProfile -ExecutionPolicy Bypass -File "%DOWNLOAD_SCRIPT%" -Version "%GRADLE_VERSION%" -ZipPath "%GRADLE_ZIP%" -DestDir "%LOCAL_DIR%"

    if errorlevel 1 (
        echo Failed to download or extract Gradle.
        echo Check your internet connection, Java 21 installation, or install Gradle manually.
        exit /b 1
    )
)

call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
