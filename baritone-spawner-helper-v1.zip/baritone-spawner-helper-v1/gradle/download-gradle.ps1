param(
    [Parameter(Mandatory = $true)]
    [string]$Version,

    [Parameter(Mandatory = $true)]
    [string]$ZipPath,

    [Parameter(Mandatory = $true)]
    [string]$DestDir
)

$ErrorActionPreference = 'Stop'
$url = "https://services.gradle.org/distributions/gradle-$Version-bin.zip"

if (-not (Test-Path -LiteralPath $DestDir)) {
    New-Item -ItemType Directory -Path $DestDir -Force | Out-Null
}

Write-Host "Downloading Gradle $Version"
Write-Host "URL: $url"
Write-Host "Target: $ZipPath"

Add-Type -AssemblyName System.Net.Http
$client = [System.Net.Http.HttpClient]::new()
$client.Timeout = [TimeSpan]::FromMinutes(30)

$response = $client.GetAsync($url, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
$response.EnsureSuccessStatusCode() | Out-Null

$totalBytes = $response.Content.Headers.ContentLength
$inputStream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
$outputStream = [System.IO.File]::Open($ZipPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)

try {
    $buffer = New-Object byte[] 1048576
    [long]$downloadedBytes = 0
    $lastPrinted = Get-Date

    while (($read = $inputStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
        $outputStream.Write($buffer, 0, $read)
        $downloadedBytes += $read

        $now = Get-Date
        if (($now - $lastPrinted).TotalMilliseconds -ge 250 -or ($totalBytes -and $downloadedBytes -eq $totalBytes)) {
            if ($totalBytes) {
                $percent = [Math]::Min(100, [Math]::Round(($downloadedBytes * 100.0) / $totalBytes, 1))
                $downloadedMb = [Math]::Round($downloadedBytes / 1MB, 1)
                $totalMb = [Math]::Round($totalBytes / 1MB, 1)
                Write-Progress -Activity "Downloading Gradle $Version" -Status "$percent% ($downloadedMb MB / $totalMb MB)" -PercentComplete $percent
                Write-Host -NoNewline "`rProgress: $percent% ($downloadedMb MB / $totalMb MB)   "
            }
            else {
                $downloadedMb = [Math]::Round($downloadedBytes / 1MB, 1)
                Write-Progress -Activity "Downloading Gradle $Version" -Status "$downloadedMb MB downloaded"
                Write-Host -NoNewline "`rDownloaded: $downloadedMb MB   "
            }
            $lastPrinted = $now
        }
    }
}
finally {
    $outputStream.Dispose()
    $inputStream.Dispose()
    $client.Dispose()
}

Write-Host ""
Write-Progress -Activity "Downloading Gradle $Version" -Completed
Write-Host "Extracting Gradle..."
Expand-Archive -LiteralPath $ZipPath -DestinationPath $DestDir -Force
Write-Host "Gradle $Version is ready."
