package id.premiumportal.baritonespawnerhelper;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class BaritoneSpawnerHelperScreen extends Screen {
    private final Screen parent;

    public BaritoneSpawnerHelperScreen(Screen parent) {
        super(Text.literal("Baritone Spawner Helper v1"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 100;
        int y = this.height / 2 - 58;

        this.addDrawableChild(ButtonWidget.builder(enabledText(), button -> {
            BaritoneSpawnerHelperClient.toggleFromScreen();
            button.setMessage(enabledText());
        }).dimensions(x, y, 200, 20).build());

        y += 26;
        this.addDrawableChild(ButtonWidget.builder(autoMineText(), button -> {
            BaritoneSpawnerHelperClient.toggleAutoMine();
            button.setMessage(autoMineText());
        }).dimensions(x, y, 200, 20).build());

        y += 26;
        this.addDrawableChild(ButtonWidget.builder(radiusText(), button -> {
            BaritoneSpawnerHelperClient.nextRadius();
            button.setMessage(radiusText());
        }).dimensions(x, y, 200, 20).build());

        y += 26;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close()).dimensions(x, y, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 24, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Default toggle: F7"), this.width / 2, 44, 0xA0A0A0);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }

    private Text enabledText() {
        return Text.literal("Baritone Spawner Helper v1: " + (BaritoneSpawnerHelperClient.config().enabled ? "ON" : "OFF"));
    }

    private Text autoMineText() {
        return Text.literal("Auto mine spawners: " + (BaritoneSpawnerHelperClient.config().autoMine ? "ON" : "OFF"));
    }

    private Text radiusText() {
        return Text.literal("Drop scan radius: " + Math.round(BaritoneSpawnerHelperClient.config().radius));
    }
}
