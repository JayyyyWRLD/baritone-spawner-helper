package id.premiumportal.baritonespawnerhelperv2;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class BaritoneSpawnerHelperV2Screen extends Screen {
    private final Screen parent;
    private ButtonWidget onButton;
    private ButtonWidget offButton;

    public BaritoneSpawnerHelperV2Screen(Screen parent) {
        super(Text.literal("Baritone Spawner Helper v2"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int panelWidth = 260;
        int x = this.width / 2 - panelWidth / 2;
        int y = this.height / 2 - 40;

        onButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("ON"), button -> {
            BaritoneSpawnerHelperV2Client.setEnabledFromScreen(true);
            refreshButtons();
        }).dimensions(x, y, 124, 24).build());

        offButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("OFF"), button -> {
            BaritoneSpawnerHelperV2Client.setEnabledFromScreen(false);
            refreshButtons();
        }).dimensions(x + 136, y, 124, 24).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), button -> close())
                .dimensions(x, y + 34, panelWidth, 22)
                .build());

        refreshButtons();
    }

    private void refreshButtons() {
        boolean enabled = BaritoneSpawnerHelperV2Client.config().enabled;
        if (onButton != null) {
            onButton.active = !enabled;
            onButton.setMessage(Text.literal(enabled ? "ON ✓" : "ON"));
        }
        if (offButton != null) {
            offButton.active = enabled;
            offButton.setMessage(Text.literal(enabled ? "OFF" : "OFF ✓"));
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int panelWidth = 300;
        int panelHeight = 118;
        int x = this.width / 2 - panelWidth / 2;
        int y = this.height / 2 - 80;

        context.fill(x, y, x + panelWidth, y + panelHeight, 0xAA101010);
        context.fill(x, y, x + panelWidth, y + 1, 0xFF555555);
        context.fill(x, y + panelHeight - 1, x + panelWidth, y + panelHeight, 0xFF555555);
        context.fill(x, y, x + 1, y + panelHeight, 0xFF555555);
        context.fill(x + panelWidth - 1, y, x + panelWidth, y + panelHeight, 0xFF555555);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, y + 16, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, statusText(), this.width / 2, y + 36, statusColor());
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }

    private Text statusText() {
        return Text.literal("Status: " + (BaritoneSpawnerHelperV2Client.config().enabled ? "ON" : "OFF"));
    }

    private int statusColor() {
        return BaritoneSpawnerHelperV2Client.config().enabled ? 0x55FF55 : 0xFF5555;
    }
}
