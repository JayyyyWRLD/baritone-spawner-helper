package id.premiumportal.baritonespawnerhelperv2;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class BaritoneSpawnerHelperV2Client implements ClientModInitializer {
    public static final String MOD_ID = "baritone_spawner_helper_v2";

    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static final long SCAN_TICKS = 5L;
    private static final long MINE_INTERVAL_MS = 10_000L;
    private static final long GOTO_INTERVAL_MS = 1_000L;
    private static final long PICKUP_TIMEOUT_MS = 25_000L;
    private static final long RESUME_DELAY_MS = 1_500L;

    private static KeyBinding toggleKey;
    private static KeyBinding configKey;
    private static RouteConfig config;
    private static Path configPath;

    private static long scanDelay;
    private static long lastMine;
    private static long lastGoto;
    private static long pickupStart;
    private static long resumeAfter;
    private static int targetId = -1;
    private static int startCount;
    private static BlockPos lastTargetPos;
    private static State state = State.MINING;
    private static boolean missingBaritoneWarned;

    @Override
    public void onInitializeClient() {
        configPath = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + ".json");
        config = RouteConfig.load(configPath);

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.baritone_spawner_helper_v2.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F7,
                "category.baritone_spawner_helper_v2"
        ));

        configKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.baritone_spawner_helper_v2.config",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "category.baritone_spawner_helper_v2"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> dispatcher.register(
                literal("baritonespawnerhelperv2")
                        .executes(context -> {
                            openConfig();
                            return 1;
                        })
                        .then(literal("config").executes(context -> {
                            openConfig();
                            return 1;
                        }))
        ));
    }

    private void tick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            openConfig();
        }

        while (configKey.wasPressed()) {
            openConfig();
        }

        if (!config.enabled || client == null || client.player == null || client.world == null) {
            return;
        }

        if (scanDelay-- > 0L) {
            return;
        }
        scanDelay = SCAN_TICKS;

        long now = System.currentTimeMillis();
        ItemEntity drop = nearestSpawnerDrop(client);

        if (drop != null) {
            routeToDrop(client, drop, now);
            return;
        }

        if (state == State.PICKUP) {
            if (pickupDone(client, now)) {
                resetPickup(client, now);
            }
            return;
        }

        if (config.autoMine && now >= resumeAfter) {
            mineSpawner(client, false);
        }
    }

    private static void routeToDrop(MinecraftClient client, ItemEntity drop, long now) {
        BlockPos pos = BlockPos.ofFloored(drop.getPos());
        boolean newTarget = state != State.PICKUP || drop.getId() != targetId;

        if (newTarget) {
            state = State.PICKUP;
            targetId = drop.getId();
            startCount = spawnerCount(client);
            pickupStart = now;
            lastGoto = 0L;
            lastTargetPos = pos;
            baritone("forcecancel", false);
            gotoPos(pos, now, true);
            say(client, "Baritone Spawner Helper v2: routing to drop at " + asText(pos), Formatting.AQUA);
            return;
        }

        lastTargetPos = pos;
        Vec3d playerPos = client.player.getPos();
        double distance = playerPos.distanceTo(drop.getPos());

        if (distance > config.collectDistance && now - lastGoto >= GOTO_INTERVAL_MS) {
            gotoPos(pos, now, false);
        }
    }

    private static void gotoPos(BlockPos pos, long now, boolean force) {
        if (pos == null) {
            return;
        }

        if (force || now - lastGoto >= GOTO_INTERVAL_MS) {
            baritone("goto " + pos.getX() + " " + pos.getY() + " " + pos.getZ(), true);
            lastGoto = now;
        }
    }

    private static void mineSpawner(MinecraftClient client, boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastMine < MINE_INTERVAL_MS) {
            return;
        }
        if (state == State.PICKUP) {
            return;
        }

        if (baritone(config.mineCommand, true)) {
            lastMine = now;
            if (config.statusMessages) {
                say(client, "Baritone Spawner Helper v2: #" + normalize(config.mineCommand), Formatting.GRAY);
            }
        }
    }

    private static boolean pickupDone(MinecraftClient client, long now) {
        if (client == null || client.player == null || client.world == null) {
            return true;
        }
        if (spawnerCount(client) > startCount) {
            return true;
        }
        if (now - pickupStart >= PICKUP_TIMEOUT_MS) {
            return true;
        }
        return targetId >= 0 && dropById(client, targetId) == null;
    }

    private static void resetPickup(MinecraftClient client, long now) {
        boolean gotItem = spawnerCount(client) > startCount;

        state = State.MINING;
        targetId = -1;
        pickupStart = 0L;
        lastGoto = 0L;
        lastTargetPos = null;
        resumeAfter = now + RESUME_DELAY_MS;
        baritone("forcecancel", false);

        if (config.statusMessages) {
            say(client, gotItem ? "Baritone Spawner Helper v2: spawner collected" : "Baritone Spawner Helper v2: resuming mining", gotItem ? Formatting.GREEN : Formatting.YELLOW);
        }

        lastMine = 0L;
    }

    private static ItemEntity nearestSpawnerDrop(MinecraftClient client) {
        Box box = client.player.getBoundingBox().expand(config.radius);
        Vec3d origin = client.player.getPos();

        List<ItemEntity> drops = client.world.getEntitiesByClass(
                ItemEntity.class,
                box,
                entity -> entity != null && entity.isAlive() && isSpawner(entity.getStack())
        );

        return drops.stream()
                .min(Comparator.comparingDouble(entity -> entity.getPos().squaredDistanceTo(origin)))
                .orElse(null);
    }

    private static ItemEntity dropById(MinecraftClient client, int id) {
        Box box = client.player.getBoundingBox().expand(config.radius + 16.0D);
        List<ItemEntity> drops = client.world.getEntitiesByClass(
                ItemEntity.class,
                box,
                entity -> entity != null && entity.isAlive() && entity.getId() == id && isSpawner(entity.getStack())
        );
        return drops.isEmpty() ? null : drops.get(0);
    }

    private static boolean isSpawner(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        String id = Registries.ITEM.getId(stack.getItem()).toString().toLowerCase(Locale.ROOT);
        return "minecraft:spawner".equals(id) || "minecraft:mob_spawner".equals(id) || id.endsWith(":spawner");
    }

    private static int spawnerCount(MinecraftClient client) {
        int total = 0;
        for (int slot = 0; slot < client.player.getInventory().size(); slot++) {
            ItemStack stack = client.player.getInventory().getStack(slot);
            if (isSpawner(stack)) {
                total += stack.getCount();
            }
        }
        return total;
    }

    private static boolean baritone(String command, boolean warn) {
        String cmd = normalize(command);
        if (cmd.isEmpty()) {
            return false;
        }

        try {
            Class<?> api = Class.forName("baritone.api.BaritoneAPI");
            Object provider = api.getMethod("getProvider").invoke(null);
            Object primary = provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);
            Object manager = primary.getClass().getMethod("getCommandManager").invoke(primary);
            Object result = manager.getClass().getMethod("execute", String.class).invoke(manager, cmd);
            return !(result instanceof Boolean) || (Boolean) result;
        } catch (ClassNotFoundException exception) {
            if (warn && !missingBaritoneWarned) {
                missingBaritoneWarned = true;
                say(MinecraftClient.getInstance(), "Baritone Spawner Helper v2: Baritone not found", Formatting.RED);
            }
            return false;
        } catch (Throwable throwable) {
            LOGGER.warn("Command failed: {}", cmd, throwable);
            return false;
        }
    }

    private static String normalize(String command) {
        if (command == null) {
            return "";
        }
        String value = command.trim();
        while (value.startsWith("#")) {
            value = value.substring(1).trim();
        }
        return value;
    }

    private static void setEnabled(MinecraftClient client, boolean enabled, boolean notify) {
        config.enabled = enabled;
        saveConfig();

        state = State.MINING;
        targetId = -1;
        pickupStart = 0L;
        lastMine = 0L;
        lastGoto = 0L;
        lastTargetPos = null;
        resumeAfter = 0L;
        missingBaritoneWarned = false;

        if (!enabled) {
            baritone("forcecancel", false);
        }

        if (notify) {
            say(client, "Baritone Spawner Helper v2: " + (enabled ? "ON" : "OFF"), enabled ? Formatting.GREEN : Formatting.RED);
        }

        if (enabled && config.autoMine) {
            mineSpawner(client, true);
        }
    }

    public static void setEnabledFromScreen(boolean enabled) {
        setEnabled(MinecraftClient.getInstance(), enabled, true);
    }

    public static void toggleAutoMine() {
        config.autoMine = !config.autoMine;
        saveConfig();
        lastMine = 0L;
        resumeAfter = 0L;
    }

    public static void nextRadius() {
        double[] values = {8.0D, 16.0D, 24.0D, 32.0D, 48.0D, 64.0D, 96.0D, 128.0D};
        double next = values[0];
        for (double value : values) {
            if (value > config.radius) {
                next = value;
                break;
            }
        }
        config.radius = next;
        saveConfig();
    }

    public static RouteConfig config() {
        return config;
    }

    private static void openConfig() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) {
            client.setScreen(new BaritoneSpawnerHelperV2Screen(client.currentScreen));
        }
    }

    private static void say(MinecraftClient client, String message, Formatting color) {
        if (client != null && client.player != null) {
            client.player.sendMessage(Text.literal(message).formatted(color), false);
        }
    }

    private static String asText(BlockPos pos) {
        return pos.getX() + " " + pos.getY() + " " + pos.getZ();
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private enum State {
        MINING,
        PICKUP
    }

    public static final class RouteConfig {
        public boolean enabled = false;
        public boolean autoMine = true;
        public boolean statusMessages = true;
        public double radius = 32.0D;
        public double collectDistance = 1.8D;
        public String mineCommand = "mine minecraft:spawner";

        static RouteConfig load(Path path) {
            if (path == null || !Files.exists(path)) {
                return new RouteConfig();
            }

            try (Reader reader = Files.newBufferedReader(path)) {
                RouteConfig loaded = GSON.fromJson(reader, RouteConfig.class);
                if (loaded == null) {
                    return new RouteConfig();
                }
                loaded.clean();
                return loaded;
            } catch (Exception exception) {
                LOGGER.warn("Config reset: {}", path, exception);
                return new RouteConfig();
            }
        }

        void clean() {
            radius = clamp(radius, 4.0D, 128.0D);
            collectDistance = clamp(collectDistance, 0.5D, 4.0D);
            if (mineCommand == null || normalize(mineCommand).isEmpty()) {
                mineCommand = "mine minecraft:spawner";
            }
        }
    }

    public static void saveConfig() {
        if (config == null || configPath == null) {
            return;
        }

        try {
            Files.createDirectories(configPath.getParent());
            try (Writer writer = Files.newBufferedWriter(configPath)) {
                GSON.toJson(config, writer);
            }
        } catch (IOException exception) {
            LOGGER.warn("Config save failed: {}", configPath, exception);
        }
    }
}
